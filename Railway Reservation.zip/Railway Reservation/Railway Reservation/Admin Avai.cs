﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Railway_Reservation
{
    public partial class Admin_Avai : Form
    {
        public Admin_Avai()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            AUI uI = new AUI();
            uI.Show();
        }
        SqlConnection con = new SqlConnection(@"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=tickets;Integrated Security=True");
        private void button2_Click(object sender, EventArgs e)
        {
            {
                SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM Trains ", con);
                DataTable dt = new DataTable();
                da.Fill(dt);
                atsg.DataSource = dt;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int trainno = int.Parse(tn.Text);
            SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM Trains where TrainNo=" + trainno + " ", con);
            DataTable dt = new DataTable();
            da.Fill(dt);
            atsg.DataSource = dt;
        }
    }
}
