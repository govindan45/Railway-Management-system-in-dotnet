﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace Railway_Reservation
{
    public partial class at : Form
    {
        public at()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            AUI uI = new AUI();
            uI.Show();
        }
        SqlConnection con = new SqlConnection(@"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=tickets;Integrated Security=True");
        private void al_Click(object sender, EventArgs e)
        {
            try
            {
                // Parse and validate user input
                int tno = int.Parse(atn.Text);  // Assuming TrainNo is an integer
                string tname = atnn.Text;
                int ass = int.Parse(avs.Text);  // Assuming AvailableSeats is an integer
                string dep = ds.Text;
                string des = es.Text;

                // Open the connection
                con.Open();

                // First check if the TrainNo already exists in the database
                string checkTrainQuery = "SELECT COUNT(1) FROM Trains WHERE TrainNo = @tno";
                SqlCommand checkCmd = new SqlCommand(checkTrainQuery, con);
                checkCmd.Parameters.AddWithValue("@tno", tno);

                // Execute the query to check if the train number already exists
                int count = (int)checkCmd.ExecuteScalar();

                // If train number exists, show an error message
                if (count > 0)
                {
                    MessageBox.Show("Error: Train number already exists. Please enter a unique TrainNo.");
                }
                else
                {
                    // Proceed with the insertion if the train number doesn't exist
                    string insertQuery = "INSERT INTO Trains (TrainNo, TrainName, AvailableSeats, train_depature, train_designation) VALUES (@tno, @tname, @ass, @dep, @des)";
                    SqlCommand insertCmd = new SqlCommand(insertQuery, con);
                    insertCmd.Parameters.AddWithValue("@tno", tno);
                    insertCmd.Parameters.AddWithValue("@tname", tname);
                    insertCmd.Parameters.AddWithValue("@ass", ass);
                    insertCmd.Parameters.AddWithValue("@dep", dep);
                    insertCmd.Parameters.AddWithValue("@des", des);

                    // Execute the insert command
                    int result = insertCmd.ExecuteNonQuery();

                    // Show success message based on result
                    MessageBox.Show((result > 0) ? "Train Added Successfully." : "Train could not be added.");

                    // Clear input fields after successful insertion
                    ClearInputFields();
                }
            }
            catch (FormatException)
            {
                // Handle format errors (e.g., if the user enters non-numeric values where an integer is expected)
                MessageBox.Show("Please ensure that all inputs are in the correct format.");
            }
            catch (SqlException ex)
            {
                // Handle SQL-related errors
                MessageBox.Show("Database Error: " + ex.Message);
            }
            catch (Exception ex)
            {
                // Handle any other types of exceptions
                MessageBox.Show("An error occurred: " + ex.Message);
            }
            finally
            {
                // Ensure the connection is closed even if an error occurs
                if (con.State == System.Data.ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }

        // Method to clear the input fields after insertion
        private void ClearInputFields()
        {
            atn.Clear();
            atnn.Clear();
            avs.Clear();
            ds.Clear();
            es.Clear();
        }

    }
    }
