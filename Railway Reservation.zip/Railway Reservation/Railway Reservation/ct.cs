﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Railway_Reservation
{
    public partial class ct : Form
    {
        public ct()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            UI uI = new UI();   
            uI.Show();
        }
        SqlConnection con = new SqlConnection(@"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=tickets;Integrated Security=True");
        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                // Parse the input values
                int bno = int.Parse(run.Text);  // Booking ID
                int tn = int.Parse(tno.Text);   // Train Number

                // Open the connection
                con.Open();

                // Start a transaction to ensure both commands succeed or fail together
                SqlTransaction transaction = con.BeginTransaction();

                // Fetch the number of booked seats from the Bookings table
                SqlCommand getTrainID = new SqlCommand("SELECT Booked_seats FROM Bookings WHERE BookingID = @bno", con, transaction);
                getTrainID.Parameters.AddWithValue("@bno", bno);

                // ExecuteScalar returns an object, so check if it's null
                object bookedSeatsObj = getTrainID.ExecuteScalar();

                // If no record is found, bookedSeatsObj will be null
                if (bookedSeatsObj == null)
                {
                    // Roll back the transaction and show an error message
                    transaction.Rollback();
                    MessageBox.Show("Error: Booking ID not found.");
                    return;  // Exit the method early
                }

                // Convert the result to an integer (since it's not null)
                int Booked_seats = Convert.ToInt32(bookedSeatsObj);

                // Delete the booking from the Bookings table
                SqlCommand cmd = new SqlCommand("DELETE FROM Bookings WHERE BookingID = @bno", con, transaction);
                cmd.Parameters.AddWithValue("@bno", bno);
                int res = cmd.ExecuteNonQuery();

                // Update the AvailableSeats in the Trains table by adding the booked seats back
                SqlCommand updateSeats = new SqlCommand("UPDATE Trains SET AvailableSeats = AvailableSeats + @Booked_seats WHERE TrainNo = @tn", con, transaction);
                updateSeats.Parameters.AddWithValue("@Booked_seats", Booked_seats);
                updateSeats.Parameters.AddWithValue("@tn", tn);
                int result = updateSeats.ExecuteNonQuery();

                // If both the delete and update are successful, commit the transaction
                if (res != 0 && result != 0)
                {
                    transaction.Commit();
                    MessageBox.Show("Cancel Successfully.");
                }
                else
                {
                    // If something fails, roll back the transaction
                    transaction.Rollback();
                    MessageBox.Show("Cancel failed.");
                }
            }
            catch (FormatException)
            {
                MessageBox.Show("Please enter valid numeric values for Booking ID and Train Number.");
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Database Error: " + ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
            finally
            {
                // Close the connection in all cases
                if (con.State == System.Data.ConnectionState.Open)
                {
                    con.Close();
                }
                // Clear the input fields
                run.Clear();
                tno.Clear();
            }
        }
    }
}
