﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Railway_Reservation
{
    public partial class bt : Form
    {
        public bt()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
            UI uI = new UI();
            uI.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            using (SqlConnection con = new SqlConnection(@"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=tickets;Integrated Security=True"))
            {
                Random random = new Random();
                int Bookingid = random.Next(0, 100);

                con.Open();
                int tno = int.Parse(run.Text);
                int bs = int.Parse(rup.Text);
                DateTime currentDateTime = DateTime.Now;
                if (bs > 0)
                {
                    SqlCommand cmd = new SqlCommand("INSERT INTO Bookings (BookingID,TrainNo, Booked_seats, Book_date) VALUES ('" + Bookingid + "'," + tno + " ," + bs + ",'" + currentDateTime + "' )", con);


                    cmd.ExecuteNonQuery();

                    SqlCommand updateSeats = new SqlCommand("UPDATE Trains SET AvailableSeats = AvailableSeats - "+bs+" WHERE TrainNo="+tno+"", con);
                    updateSeats.ExecuteNonQuery();

                    MessageBox.Show("Booking successful!"+"Your Booking Id ===="+Bookingid);

                }
            }
        }
        private void run_TextChanged(object sender, EventArgs e)
        {
            
        }
    }
}
