﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Railway_Reservation
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void Login_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form1 l = new Form1();
            this.Hide();
            l.Show();
        }

        private void lg_Click(object sender, EventArgs e)
        {
            string username = run.Text;
            string password = rup.Text;

            // Call the method to validate the user credentials
            if (ValidateUser(username, password))
            {
                // If valid, proceed to the next form (UI)
                UI uI = new UI();
                this.Hide();  // Hide the login form
                uI.Show();
            }
            else
            {
                // If invalid, show an error message
                MessageBox.Show("Invalid username or password. Please try again.");
            }

        }
        private bool ValidateUser(string username, string password)
        {
            // Define your connection string (update with your actual database connection details)
            string connectionString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=tickets;Integrated Security=True";

            // Define the SQL query to check if the username and password exist in the Users table
            string query = "SELECT COUNT(*) FROM Users WHERE Username = @username AND Password = @password";

            // Create a SqlConnection object
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                try
                {
                    // Open the connection
                    con.Open();

                    // Create a SqlCommand object to execute the query
                    using (SqlCommand cmd = new SqlCommand(query, con))
                    {
                        // Add parameters to avoid SQL injection
                        cmd.Parameters.AddWithValue("@username", username);
                        cmd.Parameters.AddWithValue("@password", password);

                        // Execute the query and get the result (the count of rows that match the username and password)
                        int count = (int)cmd.ExecuteScalar();

                        // If the count is greater than 0, the username and password are correct
                        if (count > 0)
                        {
                            return true;  // Login successful
                        }
                        else
                        {
                            return false;  // Login failed
                        }
                    }
                }
                catch (Exception ex)
                {
                    // Handle any exceptions (e.g., connection issues)
                    MessageBox.Show("Error: " + ex.Message);
                    return false;
                }
            }
        }

    }
}
