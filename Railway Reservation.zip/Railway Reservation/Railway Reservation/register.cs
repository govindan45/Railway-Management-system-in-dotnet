﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;


namespace Railway_Reservation
{
    public partial class register : Form
    {
        public register()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void lup_TextChanged(object sender, EventArgs e)
        {

        }

        private void lun_TextChanged(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
        SqlConnection con = new SqlConnection(@"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=tickets;Integrated Security=True");
        private void lg_Click(object sender, EventArgs e)
        {
            Login l=new Login();
            this.Hide();
            l.Show();
            string name = run.Text;
            string pass = rup.Text;
            SqlCommand cd = new SqlCommand("insert into Users values('" + name + "','" + pass + "')", con);
            con.Open();
            int result = cd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show((result != 0) ? "Register Successfully.."
                : "not saved..");

            run.Clear();
            rup.Clear();

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 f = new Form1();
            f.Show();
        }
    }
}
