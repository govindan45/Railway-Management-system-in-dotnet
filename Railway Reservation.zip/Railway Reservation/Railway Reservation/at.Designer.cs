﻿namespace Railway_Reservation
{
    partial class at
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.atnn = new System.Windows.Forms.TextBox();
            this.atn = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.ds = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.es = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.al = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.avs = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.label2.Location = new System.Drawing.Point(385, 72);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(396, 38);
            this.label2.TabIndex = 19;
            this.label2.Text = "Welcome to Admin Page";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 25.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.label1.Location = new System.Drawing.Point(363, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(471, 51);
            this.label1.TabIndex = 18;
            this.label1.Text = "Train Reservation App";
            // 
            // atnn
            // 
            this.atnn.AcceptsReturn = true;
            this.atnn.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.atnn.Location = new System.Drawing.Point(616, 208);
            this.atnn.Name = "atnn";
            this.atnn.Size = new System.Drawing.Size(256, 38);
            this.atnn.TabIndex = 23;
            // 
            // atn
            // 
            this.atn.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.atn.Location = new System.Drawing.Point(616, 147);
            this.atn.Name = "atn";
            this.atn.Size = new System.Drawing.Size(256, 38);
            this.atn.TabIndex = 22;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(255, 206);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(300, 38);
            this.label4.TabIndex = 21;
            this.label4.Text = "Enter Train Name:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(224, 135);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(331, 38);
            this.label3.TabIndex = 20;
            this.label3.Text = "Enter Train Number:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(175, 328);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(380, 38);
            this.label5.TabIndex = 24;
            this.label5.Text = "Enter Depature Station:";
            // 
            // ds
            // 
            this.ds.AcceptsReturn = true;
            this.ds.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ds.Location = new System.Drawing.Point(616, 328);
            this.ds.Name = "ds";
            this.ds.Size = new System.Drawing.Size(256, 38);
            this.ds.TabIndex = 25;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(134, 394);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(421, 38);
            this.label6.TabIndex = 26;
            this.label6.Text = "Enter Designation Station:";
            // 
            // es
            // 
            this.es.AcceptsReturn = true;
            this.es.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.es.Location = new System.Drawing.Point(616, 394);
            this.es.Name = "es";
            this.es.Size = new System.Drawing.Size(256, 38);
            this.es.TabIndex = 27;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.button1.Location = new System.Drawing.Point(631, 468);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(150, 60);
            this.button1.TabIndex = 29;
            this.button1.Text = "Back";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // al
            // 
            this.al.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.al.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.al.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.al.Location = new System.Drawing.Point(352, 468);
            this.al.Name = "al";
            this.al.Size = new System.Drawing.Size(212, 60);
            this.al.TabIndex = 28;
            this.al.Text = "Add Train";
            this.al.UseVisualStyleBackColor = false;
            this.al.Click += new System.EventHandler(this.al_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(195, 269);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(360, 38);
            this.label7.TabIndex = 30;
            this.label7.Text = "Enter Available Seats:";
            // 
            // avs
            // 
            this.avs.AcceptsReturn = true;
            this.avs.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.avs.Location = new System.Drawing.Point(616, 269);
            this.avs.Name = "avs";
            this.avs.Size = new System.Drawing.Size(256, 38);
            this.avs.TabIndex = 31;
            // 
            // at
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1222, 559);
            this.Controls.Add(this.avs);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.al);
            this.Controls.Add(this.es);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.ds);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.atnn);
            this.Controls.Add(this.atn);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "at";
            this.Text = "at";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox atnn;
        private System.Windows.Forms.TextBox atn;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox ds;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox es;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button al;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox avs;
    }
}