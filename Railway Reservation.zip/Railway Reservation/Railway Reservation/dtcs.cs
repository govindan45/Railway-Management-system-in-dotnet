﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Railway_Reservation
{
    public partial class dtcs : Form
    {
        public dtcs()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            AUI uI = new AUI();
            uI.Show();
        }
        SqlConnection con = new SqlConnection(@"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=tickets;Integrated Security=True");
        private void al_Click(object sender, EventArgs e)
        {
            int tno = int.Parse(atn.Text);
            SqlCommand cd = new SqlCommand("delete  from  Trains where TrainNo=" + tno + "", con);
            con.Open();
            int result = cd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show((result != 0) ? "Train Deleted Successfully.."
                : "not saved..");
            atn.Clear();
        }
    }
}
