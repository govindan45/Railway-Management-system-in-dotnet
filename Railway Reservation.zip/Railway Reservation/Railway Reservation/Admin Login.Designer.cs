﻿namespace Railway_Reservation
{
    partial class Admin_Login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.aup = new System.Windows.Forms.TextBox();
            this.aun = new System.Windows.Forms.TextBox();
            this.al = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.label2.Location = new System.Drawing.Point(342, 148);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(490, 38);
            this.label2.TabIndex = 11;
            this.label2.Text = "Welcome to Admin Login Page";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 25.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.label1.Location = new System.Drawing.Point(361, 61);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(471, 51);
            this.label1.TabIndex = 10;
            this.label1.Text = "Train Reservation App";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(245, 274);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(346, 38);
            this.label3.TabIndex = 12;
            this.label3.Text = "Enter Your Admin-ID:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(238, 372);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(356, 38);
            this.label4.TabIndex = 13;
            this.label4.Text = "Enter Your Password:";
            // 
            // aup
            // 
            this.aup.AcceptsReturn = true;
            this.aup.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.aup.Location = new System.Drawing.Point(637, 374);
            this.aup.Name = "aup";
            this.aup.Size = new System.Drawing.Size(256, 38);
            this.aup.TabIndex = 15;
            // 
            // aun
            // 
            this.aun.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.aun.Location = new System.Drawing.Point(637, 274);
            this.aun.Name = "aun";
            this.aun.Size = new System.Drawing.Size(256, 38);
            this.aun.TabIndex = 14;
            // 
            // al
            // 
            this.al.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.al.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.al.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.al.Location = new System.Drawing.Point(430, 460);
            this.al.Name = "al";
            this.al.Size = new System.Drawing.Size(162, 60);
            this.al.TabIndex = 16;
            this.al.Text = "Login";
            this.al.UseVisualStyleBackColor = false;
            this.al.Click += new System.EventHandler(this.al_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.button1.Location = new System.Drawing.Point(688, 460);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(150, 60);
            this.button1.TabIndex = 17;
            this.button1.Text = "Back";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Admin_Login
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1214, 562);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.al);
            this.Controls.Add(this.aup);
            this.Controls.Add(this.aun);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Admin_Login";
            this.Text = "Admin_Login";
            this.Load += new System.EventHandler(this.Admin_Login_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox aup;
        private System.Windows.Forms.TextBox aun;
        private System.Windows.Forms.Button al;
        private System.Windows.Forms.Button button1;
    }
}