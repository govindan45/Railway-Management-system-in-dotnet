﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Railway_Reservation
{
    public partial class AUI : Form
    {
        public AUI()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void al_Click(object sender, EventArgs e)
        {
            this.Hide();
            Admin_Avai admin_Avai = new Admin_Avai();
            admin_Avai.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            at aTS = new at();
            aTS.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            dtcs aTS = new dtcs();
            aTS.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 form1 = new Form1();
            form1.Show();
        }
    }
}
