﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace Railway_Reservation
{
    public partial class MUI : Form
    {
        public MUI()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 form1 = new Form1();
            form1.Show();
        }
        SqlConnection con = new SqlConnection(@"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=tickets;Integrated Security=True");
        private void lg_Click(object sender, EventArgs e)
        {
            string name = lun.Text;
            string pass = lup.Text;
            SqlCommand cd = new SqlCommand("insert into AUsers values('" + name + "','" + pass + "')", con);
            con.Open();
            int result = cd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show((result != 0) ? "Admin Added Successfully.."
                : "not saved..");
            lun.Clear();
            lup.Clear();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            string name = lun.Text;
            String pass = lup.Text;
            SqlCommand cd = new SqlCommand("DELETE FROM AUsers WHERE Username = @username AND Password = @password", con);
            cd.Parameters.AddWithValue("@username", name);
            cd.Parameters.AddWithValue("@password", pass);
            con.Open();
            int result = cd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show((result != 0) ? "Admin Deleted Successfully.."
                : "not Deleted..");
            lun.Clear();
            lup.Clear();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string name = lunn.Text;
            string pass = lupp.Text;
            SqlCommand cd = new SqlCommand("insert into management values('" + name + "','" + pass + "')", con);
            con.Open();
            int result = cd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show((result != 0) ? "Manager Added Successfully.."
                : "not saved..");
            lunn.Clear();
            lupp.Clear();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string names = lunn.Text;
            String passs = lupp.Text;
            SqlCommand cd = new SqlCommand("DELETE FROM management WHERE Musername = @username AND Password = @password", con);
            cd.Parameters.AddWithValue("@username", names);
            cd.Parameters.AddWithValue("@password", passs);
            con.Open();
            int result = cd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show((result != 0) ? "Manager Deleted Successfully.."
                : "not Deleted..");
            lunn.Clear();
            lupp.Clear();
        }
    }
}
